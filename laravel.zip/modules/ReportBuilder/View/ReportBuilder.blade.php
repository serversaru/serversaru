@extends('master')
@section('content')
    <div id="ajax_div">
    @include("ReportBuilderView::ReportBuilderajax")
    </div>
@endsection