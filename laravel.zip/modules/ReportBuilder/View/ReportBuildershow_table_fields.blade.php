<td data-title="reportname">{{$content->reportname}}</td>

