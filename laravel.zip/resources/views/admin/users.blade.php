@extends('master')
@section('content')
    <div id="ajax_div">
       @include('admin.userajax')
    </div>
@endsection