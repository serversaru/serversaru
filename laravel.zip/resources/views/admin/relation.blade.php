@extends('master')
@section('content')
    <div id="ajax_div">
    @include('admin.relationajax')
    </div>
@endsection