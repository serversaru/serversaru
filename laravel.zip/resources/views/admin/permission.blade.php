@extends('master')
@section('content')
    <div id="ajax_div">
        @include('admin.permissionajax')
    </div>
@endsection