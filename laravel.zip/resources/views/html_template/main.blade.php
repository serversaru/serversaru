@extends('master')
@section('content')
    <div id="ajax_div">
        @include('html_template/'.$file_name)
    </div>
@endsection
