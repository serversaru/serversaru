
					<div id="content">
						<div id="sortable-panel" class="">

							<div id="titr-content" class="col-md-12">
								<h2>Search Results</h2>
								<h5>Find anythings in admin panel...</h5>								
							</div>
													
							<div class="col-md-12 ">
								<form action="#" >
									<div class="row">
										<div class="col-sm-6">
											<div class='form-group'>								                
								                <input class="form-control" type="text" placeholder="Terms"/>
								            </div>
										</div>
										<div class="col-sm-3">
											<div class='form-group'>								                
								                <select class="form-control">
								                	<option value="">--Select Condition--</option>
								                	<option value="">All of the word</option>
								                	<option value="">Any of the word</option>
								                	<option value="">The exact phrase</option>
								                </select>
								            </div>
										</div>
										<div class="col-sm-2">
											<div class='form-group'>								                
								                <select class="form-control">
								                	<option value="">--Per Page--</option>
								                	<option value="">10</option>
								                	<option value="">20</option>
								                	<option value="">30</option>
								                </select>
								            </div>
										</div>
										<div class="col-sm-1">
											<button class="btn btn-primary" type="button">
												<i class="fa fa-search"></i> Search
											</button>
										</div>										
									</div>									
									<span class="text-muted">About 45 results (0.40 seconds)</span>
								</form>
								<div  class="panel panel-default">

									<div class="panel-body">
										
										<div class="row">
												<div class="col-md-12">
													<!-- start: SEARCH RESULT -->
													<div class="search-classic">

														<h3>Search results for 'Admin'</h3>
														<hr>
														<div class="search-result">
															<div class="row">
																<div class="col-md-8">
																	<h4 class="bold">
																		<a href="#" class="title">
																			Admin - Responsive Admin Template
																			<i class="fa fa-link grey"></i>
																		</a>
																	</h4>
																	<a href="#" class="link-url">
																		https://admin.google.com/
																	</a>
																	<p>
																		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi, obcaecati consequuntur aspernatur neque voluptatum mollitia eaque tenetur ea tempora itaque dolore incidunt explicabo voluptate quaerat at reprehenderit iste iusto asperiores?
																	</p>																	
																</div>
																<div class="col-md-4">
																	<div class="text-center"><h3>53.2 K</h3></div>
																	<span id="compositeline-big">4,1,5,7,9,9,8,7,6,6,4,7,8,4,3,2,2,5,6,7</span>																	
																</div>
															</div>
															<div class="row">
																<div class="pull-left padding-r-l-15">
																	<span class="grey">Publish on Nov 24, 2015</span>																
																</div>
																<div class="pull-right">
																	<div class="search-option padding-r-l-15 grey">
																		<a href="#" class="padding-10 grey"><i class="fa fa-tag"></i> Category</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bar-chart"></i> Performance</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-exchange"></i> Options</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bars"></i></a>
																	</div>																
																</div>
															</div>
														</div>																
														<hr>
														<div class="search-result">
															<h4 class="bold">
																<a href="#" class="title">
																	Yep Admin - Responsive Admin Dashboard Template
																</a>
															</h4>
															<img src="../assets/img/gallery/a2.jpg" width="120" alt="image" class="pull-left img-flat margin-r-l-5">
															<a href="#" class="link-url">
																https://www.google.com/work/apps/business/products/admin/
															</a>
															<p>
																Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae, ut, quis, molestias dolor nobis doloremque eos distinctio perferendis alias aspernatur quam natus necessitatibus fugiat quo nostrum ipsum tempore. Expedita eveniet impedit dolorum unde rerum temporibus.
															</p>
															<div class="row">
																<div class="pull-left padding-r-l-15">
																	<span class="grey">Publish on Nov 24, 2015</span>																
																</div>
																<div class="pull-right">
																	<div class="search-option padding-r-l-15 grey">
																		<a href="#" class="padding-10 grey"><i class="fa fa-tag"></i> Category</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bar-chart"></i> Performance</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-exchange"></i> Options</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bars"></i></a>
																	</div>																
																</div>
															</div>
														</div>
														<hr>
														<div class="search-result">
															<h4 class="bold">
																<a href="#" class="title">
																	Yep Admin - Responsive Admin Template
																</a>
															</h4>
															<a href="#" class="link-url">
																https://portal.office.com/admin/default.aspx
															</a>
															<p>
																Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit, voluptates, nulla vero beatae deserunt impedit quas fugiat cupiditate error soluta veritatis delectus cumque possimus fugit libero eligendi provident voluptatum nostrum nesciunt.
															</p>
															<div class="row">
																<div class="pull-right padding-r-l-15">
																	<span class="grey">Publish on Nov 24, 2015</span>																
																</div>
																<div class="pull-left">
																	<div class="search-option padding-r-l-15 grey">
																		<a href="#" class="padding-10 grey"><i class="fa fa-tag"></i> Category</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bar-chart"></i> Performance</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-exchange"></i> Options</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bars"></i></a>
																	</div>																
																</div>
															</div>
														</div>
														<hr>
														<div class="search-result">
															<h4 class="bold">
																<a href="#" class="title">
																	Responsive Admin Dashboard Template
																</a>
															</h4>
															<div  class="piechart pull-left" data-percent="75">
																<span class="percent">75%</span>
															</div>
															<a href="#" class="link-url">
																https://books.google.com/books?isbn=0596554265
															</a>
															<p>
																Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui, reprehenderit, cumque, quas, voluptatibus expedita aspernatur alias enim laboriosam eum sunt perspiciatis a pariatur dignissimos eligendi repellat harum hic!
															</p>
															<div class="row">
																<div class="pull-left padding-r-l-15">
																	<span class="grey">Publish on Nov 24, 2015</span>																
																</div>
																<div class="pull-right">
																	<div class="search-option padding-r-l-15 grey">
																		<a href="#" class="padding-10 grey"><i class="fa fa-tag"></i> Category</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bar-chart"></i> Performance</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-exchange"></i> Options</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bars"></i></a>
																	</div>																
																</div>
															</div>
														</div>
														<hr>
														<div class="search-result">
															<div class="row">
																<div class="col-md-8">
																	<h4 class="bold">
																		<a href="#" class="title">
																			Yeptemplate - Responsive Admin Template
																		</a>
																	</h4>
																	<a href="#" class="link-url">
																		https://www.facebook.com/Google/ <span id="inline" >5,6,7,9,9,5,3,2,2,4,6,7</span>
																	</a>
																	<p>
																		Google Inc. is an American multinational technology company specializing in Internet-related services and products. These include online advertising technologies, search, cloud computing, and software.																																				
																	</p>
																</div>
																<div class="col-md-4">
																	<div class="well">
																		<strong>Google Inc.</strong><br>
																		<strong>CEO:</strong> Sundar Pichai <br>																		
																		<strong>Headquarters:</strong> Mountain View, California, United States <br>
																		<strong>Founders:</strong> Larry Page, Sergey Brin	
																	</div>
																</div>
															</div>															
															<div class="row">
																<div class="pull-right padding-r-l-15">
																	<span class="grey">Publish on Nov 24, 2015</span>																
																</div>
																<div class="pull-left">
																	<div class="search-option padding-r-l-15 grey">
																		<a href="#" class="padding-10 grey"><i class="fa fa-tag"></i> Category</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bar-chart"></i> Performance</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-exchange"></i> Options</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bars"></i></a>
																	</div>																
																</div>
															</div>
														</div>
														<hr>
														<div class="search-result">																														
															<h4 class="bold">
																<a href="#" class="title">
																	UI/UX - Responsive Admin Dashboard Template
																</a>
															</h4>
															<div class="pull-left margin-r-l-5">
																<span id="compositebar">4,1,5,7,9,9,8,7,6,6,4,7,8,4,3,2,2,5,6,7</span>
															</div>
															<a href="#" class="link-url">
																https://en.wikipedia.org/wiki/Google
															</a>
															<p>
																Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus adipisci laborum provident enim quam! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus adipisci laborum provident enim quam!Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus adipisci laborum provident enim quam!
															</p>																	
															<div class="row">
																<div class="pull-left padding-r-l-15">
																	<span class="grey">Publish on Nov 24, 2015</span>																
																</div>
																<div class="pull-right">
																	<div class="search-option padding-r-l-15 grey">
																		<a href="#" class="padding-10 grey"><i class="fa fa-tag"></i> Category</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bar-chart"></i> Performance</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-exchange"></i> Options</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bars"></i></a>
																	</div>																
																</div>
															</div>
														</div>
														<hr>
														<div class="search-result">
															<h4 class="bold">
																<a href="#" class="title">
																	Administrator Responsive Admin Template
																</a>
															</h4>
															<a href="#" class="link-url">
																http://www.apple.com
															</a>
															<p>
																Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque, harum temporibus beatae assumenda ipsum. Dignissimos deleniti temporibus ut obcaecati possimus.
															</p>
															<div class="row">
																<div class="pull-left padding-r-l-15">
																	<span class="grey">Publish on Nov 24, 2015</span>																
																</div>
																<div class="pull-right">
																	<div class="search-option padding-r-l-15 grey">
																		<a href="#" class="padding-10 grey"><i class="fa fa-tag"></i> Category</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bar-chart"></i> Performance</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-exchange"></i> Options</a>
																		<a href="#" class="padding-10 grey"><i class="fa fa-bars"></i></a>
																	</div>																
																</div>
															</div>
														</div>
														<hr>
														<ol class="pagination text-center pull-right">
															<li class="prev disabled">
																<a href="#">
																	Prev
																</a>
															</li>
															<li class="active">
																<a href="#">
																	1
																</a>
															</li>
															<li>
																<a href="#">
																	2
																</a>
															</li>
															<li>
																<a href="#">
																	3
																</a>
															</li>
															<li>
																<a href="#">
																	4
																</a>
															</li>
															<li>
																<a href="#">
																	5
																</a>
															</li>
															<li class="next">
																<a href="#">
																	Next
																</a>
															</li>
														</ol>
													</div>
													<!-- end: SEARCH RESULT -->
												</div>
											</div>
											<!-- end: PAGE CONTENT-->
										
									</div>	
																						
								</div><!-- end panel -->
							</div><!-- end .col-md-12 -->									
							
						</div><!-- end col-md-12 -->
					</div>