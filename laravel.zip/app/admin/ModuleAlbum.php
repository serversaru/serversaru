<?php

namespace App\admin;

use Illuminate\Database\Eloquent\Model;

class ModuleAlbum extends Model
{
 
    protected $fillable = ['name','Module_type_id','Module_id'];
}
